#ifndef LIGHT_H
#define LIGHT_H

class Light {
public:
    float posX;
    float posY;
    float posZ;
    float colX;
    float colY;
    float colZ;
};

#endif